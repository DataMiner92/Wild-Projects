import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  MapPin, 
  Users, 
  FileText, 
  Target, 
  FolderOpen,
  X,
  Building2,
  ChevronLeft,
  ChevronRight,
  Settings,
  Map
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import clsx from 'clsx';

interface SidebarProps {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Digital Hubs', href: '/hubs', icon: Building2 },
  { name: 'Hub Map', href: '/hub-map', icon: Map },
  { name: 'Staff Management', href: '/staff', icon: Users },
  { name: 'User Management', href: '/users', icon: Users },
  { name: 'Reports', href: '/reports', icon: FileText },
  { name: 'Impact Tracking', href: '/impact', icon: Target },
  { name: 'File Management', href: '/files', icon: FolderOpen },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export default function Sidebar({ open, setOpen }: SidebarProps) {
  const location = useLocation();

  return (
    <>
      {/* Desktop Sidebar */}
      <motion.div
        initial={false}
        animate={{ width: open ? 256 : 64 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="hidden lg:flex lg:flex-col lg:fixed lg:inset-y-0 z-50"
      >
        <div className="flex h-full flex-col bg-gradient-to-b from-indigo-600 via-purple-600 to-pink-600 shadow-xl">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/20">
            <AnimatePresence mode="wait">
              {open ? (
                <motion.div
                  key="expanded"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center space-x-3"
                >
                  <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h1 className="text-lg font-bold text-white">
                      Digital Skilling
                    </h1>
                    <p className="text-xs text-white/70">Kenya Initiative</p>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="collapsed"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.2 }}
                  className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mx-auto"
                >
                  <Building2 className="w-5 h-5 text-white" />
                </motion.div>
              )}
            </AnimatePresence>
            
            <button
              onClick={() => setOpen(!open)}
              className="p-2 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200"
            >
              {open ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {navigation.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={clsx(
                    'group flex items-center rounded-xl transition-all duration-200 relative overflow-hidden',
                    open ? 'px-4 py-3' : 'px-3 py-3 justify-center',
                    isActive
                      ? 'bg-white/20 text-white shadow-lg backdrop-blur-sm'
                      : 'text-white/70 hover:bg-white/10 hover:text-white'
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 bg-white/20 backdrop-blur-sm rounded-xl"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  
                  <item.icon className={clsx(
                    'relative z-10 transition-all duration-200',
                    open ? 'w-5 h-5 mr-3' : 'w-5 h-5'
                  )} />
                  
                  <AnimatePresence>
                    {open && (
                      <motion.span
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        transition={{ duration: 0.2 }}
                        className="relative z-10 font-medium text-sm"
                      >
                        {item.name}
                      </motion.span>
                    )}
                  </AnimatePresence>

                  {/* Tooltip for collapsed state */}
                  {!open && (
                    <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50">
                      {item.name}
                    </div>
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Footer */}
          <div className="p-4 border-t border-white/20">
            <AnimatePresence>
              {open ? (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="flex items-center space-x-3 text-white/70"
                >
                  <MapPin className="w-4 h-4" />
                  <div className="text-xs">
                    <p className="font-medium text-white">Kenya Initiative</p>
                    <p>Digital Skills Program</p>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="flex justify-center"
                >
                  <MapPin className="w-4 h-4 text-white/70" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="lg:hidden fixed inset-y-0 left-0 z-50 w-64"
            >
              <div className="flex h-full flex-col bg-gradient-to-b from-indigo-600 via-purple-600 to-pink-600 shadow-xl">
                <div className="flex items-center justify-between p-6 border-b border-white/20">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h1 className="text-lg font-bold text-white">
                        Digital Skilling
                      </h1>
                      <p className="text-xs text-white/70">Kenya Initiative</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setOpen(false)}
                    className="p-2 rounded-md text-white/70 hover:text-white hover:bg-white/10"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <nav className="flex-1 p-4 space-y-2">
                  {navigation.map((item) => {
                    const isActive = location.pathname === item.href;
                    return (
                      <Link
                        key={item.name}
                        to={item.href}
                        onClick={() => setOpen(false)}
                        className={clsx(
                          'flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 relative overflow-hidden',
                          isActive
                            ? 'bg-white/20 text-white shadow-lg backdrop-blur-sm'
                            : 'text-white/70 hover:bg-white/10 hover:text-white'
                        )}
                      >
                        {isActive && (
                          <div className="absolute inset-0 bg-white/20 backdrop-blur-sm rounded-xl" />
                        )}
                        <item.icon className="w-5 h-5 relative z-10" />
                        <span className="font-medium relative z-10">{item.name}</span>
                      </Link>
                    );
                  })}
                </nav>

                <div className="p-4 border-t border-white/20">
                  <div className="flex items-center space-x-3 text-white/70">
                    <MapPin className="w-4 h-4" />
                    <div className="text-xs">
                      <p className="font-medium text-white">Kenya Initiative</p>
                      <p>Digital Skills Program</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}