import React, { useState } from 'react';
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User, 
  Minimize2, 
  Maximize2,
  Sparkles,
  BarChart3,
  Users,
  TrendingUp,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

const quickActions = [
  { icon: BarChart3, label: 'Generate Report', action: 'generate-report' },
  { icon: Users, label: 'Staff Analytics', action: 'staff-analytics' },
  { icon: TrendingUp, label: 'Impact Summary', action: 'impact-summary' },
  { icon: FileText, label: 'Hub Status', action: 'hub-status' }
];

const sampleMessages: Message[] = [
  {
    id: '1',
    type: 'bot',
    content: 'Hello! I\'m your AI assistant for the Digital Skilling Project. I can help you with analytics, generate reports, track performance, and answer questions about your data. What would you like to know?',
    timestamp: new Date(),
    suggestions: ['Show me this month\'s training progress', 'Generate impact report', 'Hub performance analysis', 'Staff productivity metrics']
  }
];

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>(sampleMessages);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: generateAIResponse(content),
        timestamp: new Date(),
        suggestions: generateSuggestions(content)
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 800);
  };

  const generateAIResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('report') || lowerInput.includes('generate')) {
      return 'I can help you generate various reports! Based on your current data, I can create:\n\n• Monthly Training Progress Report\n• Hub Performance Analysis\n• Staff Productivity Summary\n• Impact Measurement Report\n\nWhich type of report would you like me to generate?';
    } else if (lowerInput.includes('performance') || lowerInput.includes('analytics')) {
      return 'Here\'s a quick performance overview:\n\n📊 **Current Month Performance:**\n• Total Beneficiaries: 1,050 (+12% from last month)\n• Completion Rate: 87.2%\n• Job Placement Rate: 64.5%\n• Active Hubs: 47 locations\n\nYour Nairobi Hub is performing exceptionally well with 95% completion rate!';
    } else if (lowerInput.includes('hub') || lowerInput.includes('location')) {
      return 'Hub Status Overview:\n\n🏢 **Active Hubs: 47**\n• Nairobi Digital Hub: 95% capacity (45/50 users)\n• Mombasa Tech Center: 91% capacity (32/35 users)\n• Kisumu Innovation Hub: Under maintenance\n• Nakuru Skills Center: 93% capacity (28/30 users)\n\nWould you like detailed information about any specific hub?';
    } else if (lowerInput.includes('staff') || lowerInput.includes('team')) {
      return 'Staff Performance Summary:\n\n👥 **Team Overview:**\n• Total Staff: 142 members\n• Active: 128 (90.1%)\n• Average Performance Score: 87.3%\n• Top Performer: Sarah Wanjiku (95% rating)\n\nRecent highlights:\n• 3 new certifications completed\n• Staff satisfaction rate: 91%';
    } else if (lowerInput.includes('impact') || lowerInput.includes('success')) {
      return 'Impact Highlights:\n\n🎯 **Success Metrics:**\n• Lives Impacted: 12,847 (+24% growth)\n• Certifications Issued: 8,934\n• Job Placements: 5,672\n• New Businesses Created: 1,240\n\n**Recent Success Story:**\nGrace Wanjiru increased her income from KSh 15,000 to KSh 85,000 after completing our digital marketing program!';
    } else if (lowerInput.includes('help') || lowerInput.includes('what can you do')) {
      return 'I\'m your AI assistant for the Digital Skilling Project! Here\'s what I can help you with:\n\n🔍 **Analytics & Insights:**\n• Performance metrics and KPIs\n• Hub utilization analysis\n• Staff productivity reports\n• Training completion rates\n\n📊 **Report Generation:**\n• Monthly impact reports\n• Hub performance summaries\n• Financial analytics\n• Custom data exports\n\n💡 **Smart Recommendations:**\n• Resource optimization\n• Performance improvements\n• Strategic insights\n\nJust ask me anything about your project data!';
    } else if (lowerInput.includes('bug') || lowerInput.includes('issue') || lowerInput.includes('problem')) {
      return 'I can help you troubleshoot issues! Here are some common solutions:\n\n🔧 **Common Fixes:**\n• Try refreshing the page\n• Clear your browser cache\n• Check your internet connection\n• Ensure you have the latest browser version\n\n📞 **Need More Help?**\nIf the issue persists, please contact our support team with:\n• Description of the problem\n• Steps to reproduce\n• Browser and device information\n\nIs there a specific issue you\'re experiencing?';
    }
    
    return 'I understand you\'re asking about our digital skilling program. I can help you with:\n\n• Performance analytics and insights\n• Report generation\n• Hub management information\n• Staff performance tracking\n• Impact measurement\n\nWhat specific information would you like to explore?';
  };

  const generateSuggestions = (input: string): string[] => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('report')) {
      return ['Generate monthly impact report', 'Create hub performance analysis', 'Export staff productivity data'];
    } else if (lowerInput.includes('performance')) {
      return ['Show top performing hubs', 'Compare monthly progress', 'Staff performance rankings'];
    } else if (lowerInput.includes('hub')) {
      return ['Show hub utilization rates', 'Equipment status overview', 'Hub maintenance schedule'];
    }
    
    return ['Show training progress', 'Generate impact report', 'Hub performance analysis', 'Staff productivity metrics'];
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'generate-report':
        handleSendMessage('Generate a comprehensive monthly report');
        break;
      case 'staff-analytics':
        handleSendMessage('Show me staff performance analytics');
        break;
      case 'impact-summary':
        handleSendMessage('Give me an impact summary for this month');
        break;
      case 'hub-status':
        handleSendMessage('What\'s the current status of all hubs?');
        break;
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  if (!isOpen) {
    return (
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center z-50"
      >
        <Sparkles className="w-6 h-6" />
      </motion.button>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        className={`fixed bottom-6 right-6 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 ${
          isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-white">AI Assistant</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">Always ready to help</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Quick Actions */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <div className="grid grid-cols-2 gap-2">
                {quickActions.map((action) => (
                  <button
                    key={action.action}
                    onClick={() => handleQuickAction(action.action)}
                    className="flex items-center space-x-2 p-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <action.icon className="w-4 h-4" />
                    <span>{action.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-96">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl ${
                      message.type === 'user'
                        ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                    }`}
                  >
                    <div className="flex items-start space-x-2">
                      {message.type === 'bot' && (
                        <Bot className="w-4 h-4 mt-0.5 text-indigo-500" />
                      )}
                      <div className="flex-1">
                        <p className="text-sm whitespace-pre-line">{message.content}</p>
                        {message.suggestions && (
                          <div className="mt-2 space-y-1">
                            {message.suggestions.map((suggestion, index) => (
                              <button
                                key={index}
                                onClick={() => handleSuggestionClick(suggestion)}
                                className="block w-full text-left text-xs px-2 py-1 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
                              >
                                {suggestion}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded-2xl">
                    <div className="flex items-center space-x-2">
                      <Bot className="w-4 h-4 text-indigo-500" />
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
                  placeholder="Ask me anything about your project..."
                  className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white text-sm"
                />
                <button
                  onClick={() => handleSendMessage(inputValue)}
                  disabled={!inputValue.trim()}
                  className="p-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-lg hover:from-indigo-600 hover:to-purple-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        )}
      </motion.div>
    </AnimatePresence>
  );
}