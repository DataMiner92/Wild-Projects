import React from 'react';
import { 
  Users, 
  Building2, 
  Target, 
  TrendingUp, 
  MapPin, 
  Calendar,
  BookOpen,
  Award
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';

const statsData = [
  { icon: Users, label: 'Active Beneficiaries', value: '12,847', change: '+12%', color: 'text-blue-600' },
  { icon: Building2, label: 'Digital Hubs', value: '47', change: '+3', color: 'text-green-600' },
  { icon: BookOpen, label: 'Training Programs', value: '156', change: '+8%', color: 'text-purple-600' },
  { icon: Award, label: 'Certifications Issued', value: '8,934', change: '+24%', color: 'text-orange-600' },
];

const trainingData = [
  { month: 'Jan', beneficiaries: 450, completions: 380 },
  { month: 'Feb', beneficiaries: 520, completions: 465 },
  { month: 'Mar', beneficiaries: 680, completions: 612 },
  { month: 'Apr', beneficiaries: 750, completions: 680 },
  { month: 'May', beneficiaries: 890, completions: 801 },
  { month: 'Jun', beneficiaries: 1050, completions: 945 },
];

const hubPerformance = [
  { name: 'Nairobi Hub', performance: 95, color: '#22C55E' },
  { name: 'Mombasa Hub', performance: 88, color: '#3B82F6' },
  { name: 'Kisumu Hub', performance: 92, color: '#8B5CF6' },
  { name: 'Nakuru Hub', performance: 85, color: '#F59E0B' },
  { name: 'Eldoret Hub', performance: 78, color: '#EF4444' },
];

const impactMetrics = [
  { category: 'Digital Literacy', value: 35, color: '#22C55E' },
  { category: 'Tech Skills', value: 28, color: '#3B82F6' },
  { category: 'Entrepreneurship', value: 20, color: '#8B5CF6' },
  { category: 'Job Placement', value: 17, color: '#F59E0B' },
];

function StatCard({ icon: Icon, label, value, change, color }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{label}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
          <p className={`text-sm font-medium ${color} mt-1`}>{change} from last month</p>
        </div>
        <div className={`p-3 rounded-lg bg-gray-50 dark:bg-gray-700`}>
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
      </div>
    </motion.div>
  );
}

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Digital Skilling Impact Overview</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
            <Calendar className="w-4 h-4" />
            <span>Last updated: {new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsData.map((stat, index) => (
          <StatCard
            key={stat.label}
            icon={stat.icon}
            label={stat.label}
            value={stat.value}
            change={stat.change}
            color={stat.color}
          />
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Training Progress Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Training Progress</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={trainingData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="month" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Area
                type="monotone"
                dataKey="beneficiaries"
                stackId="1"
                stroke="#3B82F6"
                fill="#3B82F6"
                fillOpacity={0.3}
                name="Beneficiaries"
              />
              <Area
                type="monotone"
                dataKey="completions"
                stackId="1"
                stroke="#22C55E"
                fill="#22C55E"
                fillOpacity={0.3}
                name="Completions"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Hub Performance */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Hub Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={hubPerformance} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis type="number" domain={[0, 100]} stroke="#6B7280" />
              <YAxis dataKey="name" type="category" width={80} stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="performance" fill="#22C55E" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Impact Distribution and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Impact Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-1 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Impact Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={impactMetrics}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {impactMetrics.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Recent Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activities</h3>
          <div className="space-y-4">
            {[
              { action: 'New hub opened in Kisumu', time: '2 hours ago', type: 'success' },
              { action: '25 certificates issued in Nairobi Hub', time: '4 hours ago', type: 'info' },
              { action: 'Monthly report generated', time: '1 day ago', type: 'neutral' },
              { action: 'Staff training completed in Mombasa', time: '2 days ago', type: 'success' },
              { action: 'Equipment maintenance scheduled', time: '3 days ago', type: 'warning' },
            ].map((activity, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'info' ? 'bg-blue-500' :
                  activity.type === 'warning' ? 'bg-orange-500' :
                  'bg-gray-400'
                }`} />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{activity.action}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}