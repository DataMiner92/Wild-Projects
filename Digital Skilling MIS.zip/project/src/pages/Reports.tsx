import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Calendar, 
  TrendingUp, 
  Users, 
  Target,
  BarChart3,
  PieChart as PieChartIcon,
  Filter,
  Share
} from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';

const monthlyData = [
  { month: 'Jan', enrolled: 450, completed: 380, certified: 350 },
  { month: 'Feb', enrolled: 520, completed: 465, certified: 420 },
  { month: 'Mar', enrolled: 680, completed: 612, certified: 580 },
  { month: 'Apr', enrolled: 750, completed: 680, certified: 640 },
  { month: 'May', enrolled: 890, completed: 801, certified: 750 },
  { month: 'Jun', enrolled: 1050, completed: 945, certified: 890 },
];

const hubPerformance = [
  { hub: 'Nairobi', trainees: 2500, completion: 89 },
  { hub: 'Mombasa', trainees: 1800, completion: 85 },
  { hub: 'Kisumu', trainees: 1200, completion: 91 },
  { hub: 'Nakuru', trainees: 950, completion: 87 },
  { hub: 'Eldoret', trainees: 750, completion: 83 },
];

const skillCategories = [
  { name: 'Digital Literacy', value: 35, color: '#22C55E' },
  { name: 'Programming', value: 25, color: '#3B82F6' },
  { name: 'Data Analysis', value: 20, color: '#8B5CF6' },
  { name: 'Digital Marketing', value: 12, color: '#F59E0B' },
  { name: 'Cybersecurity', value: 8, color: '#EF4444' },
];

const demographicData = [
  { category: 'Age 18-25', male: 450, female: 520 },
  { category: 'Age 26-35', male: 380, female: 420 },
  { category: 'Age 36-45', male: 250, female: 290 },
  { category: 'Age 46+', male: 120, female: 140 },
];

function ReportCard({ title, description, icon: Icon, data, onGenerate }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-lg">
            <Icon className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">{description}</p>
          </div>
        </div>
        <button
          onClick={onGenerate}
          className="flex items-center space-x-2 px-3 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Generate</span>
        </button>
      </div>
      <div className="text-sm text-gray-500 dark:text-gray-400 space-y-1">
        {data.map((item: string, index: number) => (
          <div key={index} className="flex items-center justify-between">
            <span>{item}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export default function Reports() {
  const [dateRange, setDateRange] = useState('6m');
  const [reportType, setReportType] = useState('all');

  const reports = [
    {
      title: 'Monthly Impact Report',
      description: 'Comprehensive overview of training outcomes and beneficiary progress',
      icon: TrendingUp,
      data: ['Training completions', 'Certification rates', 'Job placements', 'Skill assessments']
    },
    {
      title: 'Hub Performance Analysis',
      description: 'Detailed analysis of each digital hub\'s performance metrics',
      icon: BarChart3,
      data: ['Utilization rates', 'Equipment status', 'Staff performance', 'Maintenance schedules']
    },
    {
      title: 'Beneficiary Demographics',
      description: 'Breakdown of trainees by age, gender, location, and background',
      icon: Users,
      data: ['Age distribution', 'Gender balance', 'Geographic spread', 'Education levels']
    },
    {
      title: 'Skills Assessment Report',
      description: 'Analysis of skill development and competency achievements',
      icon: Target,
      data: ['Pre/post assessments', 'Skill gaps analysis', 'Learning outcomes', 'Improvement trends']
    },
    {
      title: 'Financial Summary',
      description: 'Budget utilization and cost-effectiveness analysis',
      icon: PieChartIcon,
      data: ['Budget allocation', 'Cost per trainee', 'ROI analysis', 'Funding sources']
    },
    {
      title: 'Equipment & Assets',
      description: 'Inventory and maintenance status of all digital hub equipment',
      icon: FileText,
      data: ['Equipment inventory', 'Maintenance logs', 'Replacement schedules', 'Procurement needs']
    }
  ];

  const handleGenerateReport = (reportTitle: string) => {
    // Simulate report generation
    const reportData = {
      title: reportTitle,
      generatedAt: new Date().toISOString(),
      data: 'Sample report data...'
    };
    
    // Create and download a sample report file
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${reportTitle.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Show success message
    alert(`${reportTitle} has been generated and downloaded successfully!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Reports & Analytics</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Generate comprehensive reports and track key metrics</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="inline-flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <Share className="w-4 h-4" />
            <span>Share Dashboard</span>
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8 text-blue-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Beneficiaries</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">12,847</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Target className="w-8 h-8 text-green-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Completion Rate</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">87.2%</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Job Placement</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">64.5%</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <FileText className="w-8 h-8 text-orange-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Reports Generated</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">156</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4 text-gray-400" />
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          >
            <option value="1m">Last Month</option>
            <option value="3m">Last 3 Months</option>
            <option value="6m">Last 6 Months</option>
            <option value="1y">Last Year</option>
          </select>
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          >
            <option value="all">All Reports</option>
            <option value="impact">Impact Reports</option>
            <option value="performance">Performance Reports</option>
            <option value="financial">Financial Reports</option>
          </select>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report, index) => (
          <ReportCard
            key={index}
            title={report.title}
            description={report.description}
            icon={report.icon}
            data={report.data}
            onGenerate={() => handleGenerateReport(report.title)}
          />
        ))}
      </div>

      {/* Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Training Progress */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Training Progress Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="month" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="enrolled" stroke="#3B82F6" name="Enrolled" />
              <Line type="monotone" dataKey="completed" stroke="#22C55E" name="Completed" />
              <Line type="monotone" dataKey="certified" stroke="#8B5CF6" name="Certified" />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Hub Performance */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Hub Performance Comparison</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={hubPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="hub" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="completion" fill="#22C55E" name="Completion Rate %" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Additional Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Skills Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Skills Training Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={skillCategories}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={120}
                paddingAngle={5}
                dataKey="value"
              >
                {skillCategories.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Demographics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Beneficiary Demographics</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={demographicData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="category" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar dataKey="male" fill="#3B82F6" name="Male" />
              <Bar dataKey="female" fill="#EC4899" name="Female" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
}