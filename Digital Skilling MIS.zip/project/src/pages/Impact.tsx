import React, { useState } from 'react';
import { 
  Target, 
  TrendingUp, 
  Users, 
  Award, 
  Briefcase, 
  GraduationCap,
  MapPin,
  Calendar,
  Star,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { motion } from 'framer-motion';

const impactMetrics = [
  { 
    icon: Users, 
    label: 'Lives Impacted', 
    value: '12,847', 
    change: '+24%', 
    trend: 'up',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100 dark:bg-blue-900/20'
  },
  { 
    icon: Award, 
    label: 'Certifications', 
    value: '8,934', 
    change: '+18%', 
    trend: 'up',
    color: 'text-green-600',
    bgColor: 'bg-green-100 dark:bg-green-900/20'
  },
  { 
    icon: Briefcase, 
    label: 'Job Placements', 
    value: '5,672', 
    change: '+32%', 
    trend: 'up',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100 dark:bg-purple-900/20'
  },
  { 
    icon: GraduationCap, 
    label: 'Skills Developed', 
    value: '156', 
    change: '+12%', 
    trend: 'up',
    color: 'text-orange-600',
    bgColor: 'bg-orange-100 dark:bg-orange-900/20'
  },
];

const monthlyImpact = [
  { month: 'Jan', trainees: 450, employed: 290, entrepreneurs: 85 },
  { month: 'Feb', trainees: 520, employed: 335, entrepreneurs: 95 },
  { month: 'Mar', trainees: 680, employed: 442, entrepreneurs: 125 },
  { month: 'Apr', trainees: 750, employed: 488, entrepreneurs: 140 },
  { month: 'May', trainees: 890, employed: 578, entrepreneurs: 165 },
  { month: 'Jun', trainees: 1050, employed: 683, entrepreneurs: 195 },
];

const skillsImpact = [
  { skill: 'Digital Literacy', before: 2.1, after: 4.5, fullMark: 5 },
  { skill: 'Programming', before: 1.8, after: 4.2, fullMark: 5 },
  { skill: 'Data Analysis', before: 1.5, after: 3.9, fullMark: 5 },
  { skill: 'Entrepreneurship', before: 2.3, after: 4.1, fullMark: 5 },
  { skill: 'Digital Marketing', before: 1.9, after: 4.0, fullMark: 5 },
  { skill: 'Cybersecurity', before: 1.2, after: 3.7, fullMark: 5 },
];

const successStories = [
  {
    id: 1,
    name: 'Grace Wanjiru',
    age: 24,
    location: 'Nairobi',
    story: 'Started as a domestic worker, now runs a successful e-commerce business after completing our digital marketing program.',
    outcome: 'Monthly income increased from KSh 15,000 to KSh 85,000',
    program: 'Digital Marketing & E-commerce',
    image: 'https://images.pexels.com/photos/3756681/pexels-photo-3756681.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2'
  },
  {
    id: 2,
    name: 'John Kipchoge',
    age: 28,
    location: 'Eldoret',
    story: 'Unemployed graduate who learned web development and now works remotely for international clients.',
    outcome: 'Secured 3 international contracts worth KSh 120,000/month',
    program: 'Web Development Bootcamp',
    image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2'
  },
  {
    id: 3,
    name: 'Fatuma Hassan',
    age: 31,
    location: 'Mombasa',
    story: 'Single mother who learned data analysis and now provides insights for local NGOs and government agencies.',
    outcome: 'Established data consultancy serving 12 organizations',
    program: 'Data Analysis & Visualization',
    image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2'
  }
];

const impactByRegion = [
  { region: 'Nairobi', beneficiaries: 3200, employed: 2080, businesses: 450 },
  { region: 'Mombasa', beneficiaries: 2100, employed: 1365, businesses: 290 },
  { region: 'Kisumu', beneficiaries: 1800, employed: 1170, businesses: 240 },
  { region: 'Nakuru', beneficiaries: 1500, employed: 975, businesses: 200 },
  { region: 'Eldoret', beneficiaries: 1200, employed: 780, businesses: 160 },
];

function ImpactCard({ icon: Icon, label, value, change, trend, color, bgColor }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{label}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
          <div className="flex items-center space-x-1 mt-2">
            {trend === 'up' ? (
              <ArrowUp className="w-4 h-4 text-green-500" />
            ) : (
              <ArrowDown className="w-4 h-4 text-red-500" />
            )}
            <span className={`text-sm font-medium ${trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
              {change}
            </span>
            <span className="text-sm text-gray-500 dark:text-gray-400">vs last period</span>
          </div>
        </div>
        <div className={`p-3 rounded-lg ${bgColor}`}>
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
      </div>
    </motion.div>
  );
}

function SuccessStoryCard({ story }: { story: any }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200"
    >
      <div className="flex items-start space-x-4">
        <img
          src={story.image}
          alt={story.name}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{story.name}</h3>
            <span className="text-sm text-gray-500 dark:text-gray-400">• Age {story.age}</span>
          </div>
          <div className="flex items-center space-x-2 mb-3">
            <MapPin className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-600 dark:text-gray-400">{story.location}</span>
            <span className="px-2 py-1 text-xs bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full">
              {story.program}
            </span>
          </div>
          <p className="text-gray-700 dark:text-gray-300 text-sm mb-3">{story.story}</p>
          <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
            <p className="text-sm font-medium text-green-800 dark:text-green-300">{story.outcome}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function Impact() {
  const [timeFrame, setTimeFrame] = useState('6m');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Impact Tracking</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Measure and showcase the impact of digital skilling initiatives</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-gray-400" />
            <select
              value={timeFrame}
              onChange={(e) => setTimeFrame(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
            >
              <option value="3m">Last 3 Months</option>
              <option value="6m">Last 6 Months</option>
              <option value="1y">Last Year</option>
              <option value="all">All Time</option>
            </select>
          </div>
        </div>
      </div>

      {/* Impact Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {impactMetrics.map((metric, index) => (
          <ImpactCard
            key={metric.label}
            icon={metric.icon}
            label={metric.label}
            value={metric.value}
            change={metric.change}
            trend={metric.trend}
            color={metric.color}
            bgColor={metric.bgColor}
          />
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Impact Trend */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Monthly Impact Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={monthlyImpact}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="month" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#F9FAFB',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Area
                type="monotone"
                dataKey="trainees"
                stackId="1"
                stroke="#3B82F6"
                fill="#3B82F6"
                fillOpacity={0.3}
                name="Trainees"
              />
              <Area
                type="monotone"
                dataKey="employed"
                stackId="2"
                stroke="#22C55E"
                fill="#22C55E"
                fillOpacity={0.3}
                name="Employed"
              />
              <Area
                type="monotone"
                dataKey="entrepreneurs"
                stackId="3"
                stroke="#8B5CF6"
                fill="#8B5CF6"
                fillOpacity={0.3}
                name="Entrepreneurs"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Skills Development Radar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Skills Development Impact</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={skillsImpact}>
              <PolarGrid stroke="#E5E7EB" />
              <PolarAngleAxis dataKey="skill" tick={{ fontSize: 12 }} />
              <PolarRadiusAxis 
                angle={30} 
                domain={[0, 5]} 
                tick={{ fontSize: 10 }}
              />
              <Radar
                name="Before Training"
                dataKey="before"
                stroke="#EF4444"
                fill="#EF4444"
                fillOpacity={0.2}
              />
              <Radar
                name="After Training"
                dataKey="after"
                stroke="#22C55E"
                fill="#22C55E"
                fillOpacity={0.3}
              />
              <Legend />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Success Stories */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <Star className="w-6 h-6 text-yellow-500" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Success Stories</h3>
          </div>
          <button className="text-sm text-green-600 hover:text-green-700 font-medium">
            View All Stories →
          </button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {successStories.map((story) => (
            <SuccessStoryCard key={story.id} story={story} />
          ))}
        </div>
      </motion.div>

      {/* Regional Impact */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700"
      >
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Impact by Region</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Region</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Beneficiaries</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Employed</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">New Businesses</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Success Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {impactByRegion.map((region, index) => (
                <tr key={region.region} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="font-medium text-gray-900 dark:text-white">{region.region}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-600 dark:text-gray-400">{region.beneficiaries.toLocaleString()}</td>
                  <td className="py-3 px-4 text-gray-600 dark:text-gray-400">{region.employed.toLocaleString()}</td>
                  <td className="py-3 px-4 text-gray-600 dark:text-gray-400">{region.businesses}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-1 text-xs bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full">
                      {Math.round((region.employed / region.beneficiaries) * 100)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}