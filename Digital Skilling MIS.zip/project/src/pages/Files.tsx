import React, { useState } from 'react';
import { 
  Upload, 
  FileText, 
  Download, 
  Trash2, 
  Search, 
  Filter, 
  FolderOpen,
  File,
  Image as ImageIcon,
  Video,
  Archive,
  Plus,
  MoreVertical,
  Eye,
  Edit,
  Share
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

interface FileItem {
  id: string;
  name: string;
  type: 'document' | 'image' | 'video' | 'archive' | 'other';
  size: number;
  uploadDate: Date;
  uploadedBy: string;
  category: string;
  url: string;
}

const mockFiles: FileItem[] = [
  {
    id: '1',
    name: 'Monthly Training Report - June 2024.pdf',
    type: 'document',
    size: 2450000,
    uploadDate: new Date('2024-06-30'),
    uploadedBy: 'Sarah Wanjiku',
    category: 'Reports',
    url: '#'
  },
  {
    id: '2',
    name: 'Nairobi Hub Photos.zip',
    type: 'archive',
    size: 15600000,
    uploadDate: new Date('2024-06-28'),
    uploadedBy: 'John Kamau',
    category: 'Media',
    url: '#'
  },
  {
    id: '3',
    name: 'Digital Literacy Curriculum.docx',
    type: 'document',
    size: 890000,
    uploadDate: new Date('2024-06-25'),
    uploadedBy: 'Grace Otieno',
    category: 'Training Materials',
    url: '#'
  },
  {
    id: '4',
    name: 'Success Story - Grace Wanjiru.mp4',
    type: 'video',
    size: 45000000,
    uploadDate: new Date('2024-06-20'),
    uploadedBy: 'Ahmed Hassan',
    category: 'Success Stories',
    url: '#'
  },
  {
    id: '5',
    name: 'Hub Equipment Inventory.xlsx',
    type: 'document',
    size: 340000,
    uploadDate: new Date('2024-06-18'),
    uploadedBy: 'Peter Kinyua',
    category: 'Inventory',
    url: '#'
  },
  {
    id: '6',
    name: 'Training Session Photo.jpg',
    type: 'image',
    size: 1200000,
    uploadDate: new Date('2024-06-15'),
    uploadedBy: 'Mary Njeri',
    category: 'Media',
    url: '#'
  }
];

function getFileIcon(type: string) {
  switch (type) {
    case 'document':
      return FileText;
    case 'image':
      return ImageIcon;
    case 'video':
      return Video;
    case 'archive':
      return Archive;
    default:
      return File;
  }
}

function formatFileSize(bytes: number) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function FileCard({ file }: { file: FileItem }) {
  const [showMenu, setShowMenu] = useState(false);
  const Icon = getFileIcon(file.type);

  const typeColors = {
    document: 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400',
    image: 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400',
    video: 'bg-purple-100 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400',
    archive: 'bg-orange-100 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400',
    other: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-all duration-200"
    >
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className={`p-3 rounded-lg ${typeColors[file.type]}`}>
            <Icon className="w-6 h-6" />
          </div>
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
            <AnimatePresence>
              {showMenu && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="absolute top-full right-0 mt-2 w-40 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2 z-10"
                >
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center space-x-2">
                    <Eye className="w-4 h-4" />
                    <span>Preview</span>
                  </button>
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center space-x-2">
                    <Download className="w-4 h-4" />
                    <span>Download</span>
                  </button>
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center space-x-2">
                    <Share className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center space-x-2">
                    <Edit className="w-4 h-4" />
                    <span>Rename</span>
                  </button>
                  <button className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center space-x-2">
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="font-medium text-gray-900 dark:text-white text-sm line-clamp-2">
            {file.name}
          </h3>
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span>{formatFileSize(file.size)}</span>
            <span>{format(file.uploadDate, 'MMM d, yyyy')}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full">
              {file.category}
            </span>
            <span className="text-xs text-gray-500 dark:text-gray-400">
              by {file.uploadedBy}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function Files() {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const filteredFiles = mockFiles.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         file.uploadedBy.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || file.category === categoryFilter;
    const matchesType = typeFilter === 'all' || file.type === typeFilter;
    return matchesSearch && matchesCategory && matchesType;
  });

  const categories = [...new Set(mockFiles.map(file => file.category))];
  const types = [...new Set(mockFiles.map(file => file.type))];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      // Handle file upload
      const files = Array.from(e.dataTransfer.files);
      files.forEach(file => {
        console.log('Uploading file:', file.name);
        // In a real app, you would upload the file to your server
        alert(`File "${file.name}" uploaded successfully!`);
      });
    }
  };

  const totalSize = mockFiles.reduce((sum, file) => sum + file.size, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">File Management</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Organize and manage project files and documents</p>
        </div>
        <button
          onClick={() => setShowUploadModal(true)}
          className="inline-flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Upload Files</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <FolderOpen className="w-8 h-8 text-blue-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Files</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">{mockFiles.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Archive className="w-8 h-8 text-green-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Size</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">{formatFileSize(totalSize)}</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <FileText className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Documents</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">
                {mockFiles.filter(f => f.type === 'document').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <ImageIcon className="w-8 h-8 text-orange-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Media Files</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">
                {mockFiles.filter(f => f.type === 'image' || f.type === 'video').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
          dragActive 
            ? 'border-green-500 bg-green-50 dark:bg-green-900/20' 
            : 'border-gray-300 dark:border-gray-600 hover:border-green-400'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-lg font-medium text-gray-900 dark:text-white mb-2">
          Drop files here or click to upload
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Support for documents, images, videos, and archives up to 50MB
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search files by name or uploader..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          >
            <option value="all">All Categories</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          >
            <option value="all">All Types</option>
            {types.map(type => (
              <option key={type} value={type}>{type.charAt(0).toUpperCase() + type.slice(1)}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Files Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredFiles.map((file) => (
          <FileCard key={file.id} file={file} />
        ))}
      </div>

      {filteredFiles.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No files found matching your criteria</p>
        </div>
      )}
    </div>
  );
}