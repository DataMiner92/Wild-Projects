import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Layers, Search, Filter, Building2, Users, Wifi, Computer, X, ZoomIn, ZoomOut, Maximize2, Minimize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Hub {
  id: string;
  name: string;
  location: string;
  county: string;
  coordinates: { lat: number; lng: number };
  status: 'active' | 'maintenance' | 'inactive';
  capacity: number;
  currentUsers: number;
  equipment: {
    computers: number;
    internetSpeed: string;
    printers: number;
  };
  coordinator: string;
  established: string;
  image: string;
}

const hubs: Hub[] = [
  {
    id: '1',
    name: 'Nairobi Digital Hub',
    location: 'CBD, Nairobi',
    county: 'Nairobi',
    coordinates: { lat: -1.2921, lng: 36.8219 },
    status: 'active',
    capacity: 50,
    currentUsers: 45,
    equipment: { computers: 25, internetSpeed: '100 Mbps', printers: 3 },
    coordinator: 'Sarah Wanjiku',
    established: '2023-01-15',
    image: 'https://images.pexels.com/photos/159306/network-cable-ethernet-computer-159306.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '2',
    name: 'Mombasa Tech Center',
    location: 'Old Town, Mombasa',
    county: 'Mombasa',
    coordinates: { lat: -4.0435, lng: 39.6682 },
    status: 'active',
    capacity: 35,
    currentUsers: 32,
    equipment: { computers: 18, internetSpeed: '50 Mbps', printers: 2 },
    coordinator: 'Ahmed Hassan',
    established: '2023-03-10',
    image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '3',
    name: 'Kisumu Innovation Hub',
    location: 'Milimani, Kisumu',
    county: 'Kisumu',
    coordinates: { lat: -0.0917, lng: 34.7680 },
    status: 'maintenance',
    capacity: 40,
    currentUsers: 0,
    equipment: { computers: 20, internetSpeed: '75 Mbps', printers: 2 },
    coordinator: 'Grace Otieno',
    established: '2023-05-20',
    image: 'https://images.pexels.com/photos/3184302/pexels-photo-3184302.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '4',
    name: 'Nakuru Skills Center',
    location: 'Section 58, Nakuru',
    county: 'Nakuru',
    coordinates: { lat: -0.3031, lng: 36.0800 },
    status: 'active',
    capacity: 30,
    currentUsers: 28,
    equipment: { computers: 15, internetSpeed: '50 Mbps', printers: 2 },
    coordinator: 'Peter Kinyua',
    established: '2023-07-05',
    image: 'https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '5',
    name: 'Eldoret Digital Center',
    location: 'Eldoret Town, Uasin Gishu',
    county: 'Uasin Gishu',
    coordinates: { lat: 0.5143, lng: 35.2698 },
    status: 'active',
    capacity: 25,
    currentUsers: 22,
    equipment: { computers: 12, internetSpeed: '50 Mbps', printers: 1 },
    coordinator: 'Daniel Kiprop',
    established: '2023-08-12',
    image: 'https://images.pexels.com/photos/3184298/pexels-photo-3184298.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '6',
    name: 'Machakos Tech Hub',
    location: 'Machakos Town',
    county: 'Machakos',
    coordinates: { lat: -1.5177, lng: 37.2634 },
    status: 'active',
    capacity: 20,
    currentUsers: 18,
    equipment: { computers: 10, internetSpeed: '50 Mbps', printers: 1 },
    coordinator: 'Mary Mutua',
    established: '2023-09-01',
    image: 'https://images.pexels.com/photos/3184299/pexels-photo-3184299.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '7',
    name: 'Nyeri Innovation Center',
    location: 'Nyeri Town',
    county: 'Nyeri',
    coordinates: { lat: -0.4167, lng: 36.9500 },
    status: 'active',
    capacity: 35,
    currentUsers: 30,
    equipment: { computers: 18, internetSpeed: '75 Mbps', printers: 2 },
    coordinator: 'James Kariuki',
    established: '2023-10-15',
    image: 'https://images.pexels.com/photos/3184300/pexels-photo-3184300.jpeg?auto=compress&cs=tinysrgb&w=400'
  }
];

function HubMarker({ hub, isSelected, onClick, mapBounds, zoomLevel }: { 
  hub: Hub; 
  isSelected: boolean; 
  onClick: () => void;
  mapBounds: { width: number; height: number };
  zoomLevel: number;
}) {
  const statusColors = {
    active: 'bg-green-500 border-green-600 shadow-green-500/50',
    maintenance: 'bg-orange-500 border-orange-600 shadow-orange-500/50',
    inactive: 'bg-red-500 border-red-600 shadow-red-500/50'
  };

  // Calculate position based on Kenya's bounds with zoom
  const kenyaBounds = {
    north: 5.0,
    south: -4.5,
    east: 42.0,
    west: 33.5
  };

  const baseX = ((hub.coordinates.lng - kenyaBounds.west) / (kenyaBounds.east - kenyaBounds.west)) * 100;
  const baseY = ((kenyaBounds.north - hub.coordinates.lat) / (kenyaBounds.north - kenyaBounds.south)) * 100;

  // Apply zoom scaling
  const centerX = 50;
  const centerY = 50;
  const x = centerX + (baseX - centerX) * zoomLevel;
  const y = centerY + (baseY - centerY) * zoomLevel;

  // Ensure markers stay within bounds
  const clampedX = Math.max(5, Math.min(95, x));
  const clampedY = Math.max(5, Math.min(95, y));

  const markerSize = Math.max(24, 32 * zoomLevel);

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.3, zIndex: 30 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group ${
        isSelected ? 'z-40' : 'z-20'
      }`}
      style={{
        left: `${clampedX}%`,
        top: `${clampedY}%`,
        width: `${markerSize}px`,
        height: `${markerSize}px`
      }}
      onClick={onClick}
    >
      {/* Marker */}
      <div className={`relative w-full h-full rounded-full border-2 ${statusColors[hub.status]} shadow-lg transition-all duration-200`}>
        {/* Pulse animation for active hubs */}
        {hub.status === 'active' && (
          <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
        )}
        
        {/* Hub icon */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Building2 className="w-1/2 h-1/2 text-white" />
        </div>
      </div>

      {/* Tooltip on hover */}
      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-50">
        <div className="bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap shadow-lg">
          {hub.name}
        </div>
      </div>

      {/* Detailed popup when selected */}
      <AnimatePresence>
        {isSelected && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 10 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="absolute top-full left-1/2 mt-3 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50"
            style={{
              // Smart positioning to avoid going off-screen
              left: clampedX > 70 ? 'auto' : '50%',
              right: clampedX > 70 ? '0' : 'auto',
              transform: clampedX > 70 ? 'translateX(0)' : 'translateX(-50%)',
              top: clampedY > 70 ? 'auto' : '100%',
              bottom: clampedY > 70 ? '100%' : 'auto'
            }}
          >
            {/* Header with image */}
            <div className="relative h-32">
              <img src={hub.image} alt={hub.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-3 left-3 text-white">
                <h3 className="font-bold text-lg">{hub.name}</h3>
                <p className="text-sm opacity-90">{hub.location}, {hub.county}</p>
              </div>
              <div className="absolute top-3 right-3">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  hub.status === 'active' ? 'bg-green-500 text-white' :
                  hub.status === 'maintenance' ? 'bg-orange-500 text-white' :
                  'bg-red-500 text-white'
                }`}>
                  {hub.status.charAt(0).toUpperCase() + hub.status.slice(1)}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="p-4 space-y-4">
              {/* Utilization */}
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600 dark:text-gray-400">Utilization</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {hub.currentUsers}/{hub.capacity} ({Math.round((hub.currentUsers / hub.capacity) * 100)}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(hub.currentUsers / hub.capacity) * 100}%` }}
                  />
                </div>
              </div>

              {/* Equipment */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Computer className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Computers</p>
                    <p className="font-medium text-gray-900 dark:text-white">{hub.equipment.computers}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Wifi className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Internet</p>
                    <p className="font-medium text-gray-900 dark:text-white">{hub.equipment.internetSpeed}</p>
                  </div>
                </div>
              </div>

              {/* Coordinator */}
              <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
                <p className="text-xs text-gray-500 dark:text-gray-400">Coordinator</p>
                <p className="font-medium text-gray-900 dark:text-white">{hub.coordinator}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function HubCard({ hub, onLocate }: { hub: Hub; onLocate: (hubId: string) => void }) {
  const statusColors = {
    active: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300',
    maintenance: 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300',
    inactive: 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300'
  };

  const utilizationPercentage = (hub.currentUsers / hub.capacity) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-all duration-200"
    >
      <img src={hub.image} alt={hub.name} className="w-full h-24 object-cover" />
      <div className="p-3">
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-sm text-gray-900 dark:text-white truncate">{hub.name}</h3>
            <div className="flex items-center space-x-1 text-xs text-gray-600 dark:text-gray-400 mt-1">
              <MapPin className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{hub.location}</span>
            </div>
          </div>
          <span className={`px-2 py-1 text-xs font-medium rounded-full flex-shrink-0 ml-2 ${statusColors[hub.status]}`}>
            {hub.status.charAt(0).toUpperCase() + hub.status.slice(1)}
          </span>
        </div>

        <div className="space-y-2">
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-gray-600 dark:text-gray-400">Utilization</span>
              <span className="font-medium">{hub.currentUsers}/{hub.capacity}</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
              <div 
                className="bg-gradient-to-r from-indigo-500 to-purple-500 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${utilizationPercentage}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center space-x-1">
              <Computer className="w-3 h-3 text-gray-400 flex-shrink-0" />
              <span className="truncate">{hub.equipment.computers} PCs</span>
            </div>
            <div className="flex items-center space-x-1">
              <Wifi className="w-3 h-3 text-gray-400 flex-shrink-0" />
              <span className="truncate">{hub.equipment.internetSpeed}</span>
            </div>
          </div>

          <button
            onClick={() => onLocate(hub.id)}
            className="w-full mt-2 px-3 py-1.5 bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-xs rounded-lg hover:from-indigo-600 hover:to-purple-600 transition-all duration-200"
          >
            Locate on Map
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function HubMap() {
  const [selectedHub, setSelectedHub] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [mapView, setMapView] = useState<'satellite' | 'terrain' | 'roadmap'>('roadmap');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [mapBounds, setMapBounds] = useState({ width: 800, height: 600 });

  const filteredHubs = hubs.filter(hub => {
    const matchesSearch = hub.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         hub.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         hub.county.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || hub.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleLocateHub = (hubId: string) => {
    setSelectedHub(hubId);
    // Scroll to map if on mobile
    const mapElement = document.getElementById('hub-map');
    if (mapElement && window.innerWidth < 1024) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Close popup when clicking outside
  const handleMapClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      setSelectedHub(null);
    }
  };

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 0.2, 2));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 0.2, 0.5));
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const getMapBackground = () => {
    switch (mapView) {
      case 'satellite':
        return 'bg-gradient-to-br from-green-800 via-yellow-700 to-blue-800';
      case 'terrain':
        return 'bg-gradient-to-br from-green-600 via-yellow-500 to-brown-600';
      default:
        return 'bg-gradient-to-br from-green-200 via-yellow-100 to-blue-200 dark:from-gray-600 dark:via-gray-700 dark:to-gray-800';
    }
  };

  useEffect(() => {
    const updateMapBounds = () => {
      const mapElement = document.getElementById('hub-map');
      if (mapElement) {
        const rect = mapElement.getBoundingClientRect();
        setMapBounds({ width: rect.width, height: rect.height });
      }
    };

    updateMapBounds();
    window.addEventListener('resize', updateMapBounds);
    return () => window.removeEventListener('resize', updateMapBounds);
  }, [isFullscreen]);

  const MapComponent = () => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Kenya Digital Hubs Map</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Click on markers to view hub details</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={toggleFullscreen}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            {selectedHub && (
              <button
                onClick={() => setSelectedHub(null)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
      
      <div 
        id="hub-map"
        className={`relative ${isFullscreen ? 'h-screen' : 'h-[500px]'} ${getMapBackground()} overflow-hidden cursor-pointer transition-all duration-300`}
        onClick={handleMapClick}
        style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center' }}
      >
        {/* Kenya Map Outline */}
        <div className="absolute inset-0 opacity-30">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <path
              d="M20,30 Q25,25 35,28 Q45,25 55,30 Q65,28 75,35 Q80,45 78,55 Q75,65 70,70 Q60,75 50,73 Q40,75 30,70 Q25,60 22,50 Q20,40 20,30 Z"
              fill="rgba(34, 197, 94, 0.2)"
              stroke="rgba(34, 197, 94, 0.4)"
              strokeWidth="0.5"
            />
          </svg>
        </div>
        
        {/* Hub Markers */}
        {filteredHubs.map((hub) => (
          <HubMarker
            key={hub.id}
            hub={hub}
            isSelected={selectedHub === hub.id}
            onClick={() => setSelectedHub(selectedHub === hub.id ? null : hub.id)}
            mapBounds={mapBounds}
            zoomLevel={zoomLevel}
          />
        ))}

        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col space-y-2">
          <button 
            onClick={handleZoomIn}
            className="p-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <ZoomIn className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          </button>
          <button 
            onClick={handleZoomOut}
            className="p-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <ZoomOut className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        {/* Map Legend */}
        <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 border border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Status Legend</h4>
          <div className="space-y-1">
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-green-500 rounded-full shadow-sm" />
              <span className="text-gray-600 dark:text-gray-400">Active ({hubs.filter(h => h.status === 'active').length})</span>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-orange-500 rounded-full shadow-sm" />
              <span className="text-gray-600 dark:text-gray-400">Maintenance ({hubs.filter(h => h.status === 'maintenance').length})</span>
            </div>
            <div className="flex items-center space-x-2 text-xs">
              <div className="w-3 h-3 bg-red-500 rounded-full shadow-sm" />
              <span className="text-gray-600 dark:text-gray-400">Inactive ({hubs.filter(h => h.status === 'inactive').length})</span>
            </div>
          </div>
        </div>

        {/* View Mode Indicator */}
        <div className="absolute top-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg px-3 py-2 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-gray-600 dark:text-gray-400" />
            <span className="text-sm font-medium text-gray-900 dark:text-white capitalize">{mapView}</span>
          </div>
        </div>
      </div>
    </div>
  );

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 z-50 bg-gray-50 dark:bg-gray-900">
        <div className="h-full p-4">
          <MapComponent />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Hub Locations</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Interactive map view of all digital hubs across Kenya</p>
        </div>
        <div className="flex items-center space-x-2">
          <Layers className="w-4 h-4 text-gray-400" />
          <select
            value={mapView}
            onChange={(e) => setMapView(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          >
            <option value="roadmap">Roadmap</option>
            <option value="satellite">Satellite</option>
            <option value="terrain">Terrain</option>
          </select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Building2 className="w-8 h-8 text-blue-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Hubs</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">{hubs.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Active</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">
                {hubs.filter(h => h.status === 'active').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Capacity</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">
                {hubs.reduce((sum, hub) => sum + hub.capacity, 0)}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Navigation className="w-8 h-8 text-orange-600" />
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Counties</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white">
                {new Set(hubs.map(h => h.county)).size}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search hubs by name, location, or county..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="maintenance">Maintenance</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Map */}
        <div className="lg:col-span-2">
          <MapComponent />
        </div>

        {/* Hub Directory */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Hub Directory</h3>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {filteredHubs.length} of {hubs.length} hubs
            </span>
          </div>
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
            {filteredHubs.map((hub) => (
              <HubCard 
                key={hub.id} 
                hub={hub} 
                onLocate={handleLocateHub}
              />
            ))}
          </div>
          {filteredHubs.length === 0 && (
            <div className="text-center py-8">
              <MapPin className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500 dark:text-gray-400">No hubs found matching your criteria</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}